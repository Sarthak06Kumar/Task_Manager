# Task Manager Web Application

This is a simple Task Manager web application developed as part of a Software Developer internship assessment.  
The application allows users to register, log in, and manage their tasks with full CRUD functionality.

---

## 🚀 Features

- User Registration and Login
- Session-based Authentication
- Create, Read, Update, Delete (CRUD) Tasks
- User-specific task management
- MySQL database integration
- Clean and simple UI

---

## 🛠️ Tech Stack

- Backend: Flask (Python)
- Frontend: HTML, CSS
- Database: MySQL
- Version Control: Git & GitHub

---

## 📂 Project Structure

task_manager_flask/
│
├── app.py
├── config.py
├── requirements.txt
│
├── static/
│ └── css/
│ └── style.css
│
├── templates/
│ ├── login.html
│ ├── register.html
│ ├── dashboard.html
│ ├── edit_task.html
│
└── README.md

